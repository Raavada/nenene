

def main():
    print("from main")

def tota1l(a,b):
    c=a+b
    print("Inside sum",a+b)
    return c

if __name__=='__main__':
    main()
    tota1l(2,3)
