

def main():
    print("from main")

def tota1l(a,b):
    print("Inside sum",a+b)
    return sum(a+b)

if __name__=='__main__':
    main()
